"""Infeasibility diagnostics."""
