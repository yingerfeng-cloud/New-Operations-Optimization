"""Solver adapters."""
