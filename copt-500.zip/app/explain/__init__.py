"""Business result formatters."""
