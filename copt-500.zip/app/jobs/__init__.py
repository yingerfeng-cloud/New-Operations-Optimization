"""Solve job execution."""
