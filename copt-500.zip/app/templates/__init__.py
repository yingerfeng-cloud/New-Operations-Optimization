"""Power model template library."""
