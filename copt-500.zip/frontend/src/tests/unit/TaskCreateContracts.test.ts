import { describe, expect, test } from 'vitest';
import { buildTaskPayload } from '../../features/task-create/utils/buildTaskPayload';
import { deriveHorizon, managedTimeFields, validateRuntimeTimeDimension, type RuntimeField, type TimeDimensionConfig } from '../../features/time-dimension';

const base = (overrides: Partial<TimeDimensionConfig>): TimeDimensionConfig => ({ enabled: true, policy: 'fixed', time_set: 'time', state_time_set: null, editable: false, allowed_horizons: [], interval_minutes_by_horizon: {}, delta_t_by_horizon: {}, ...overrides });
const series: RuntimeField = { code: 'load_forecast', name: '负荷预测', required: true, dimension: ['time'] };

describe('task create contract gate', () => {
  test('not_applicable never injects horizon', () => {
    const config = base({ enabled: false, policy: 'not_applicable' });
    const payload = buildTaskPayload({ model_id: 'm1', solver: 'HiGHS', horizon: 24, parameters: { demand: 100 } }, config);
    expect(payload).not.toHaveProperty('horizon');
    expect(payload.runtime_parameters).toEqual({ demand: 100 });
  });

  test('fixed horizon is read-only and omitted from legacy payload fields', () => {
    const config = base({ policy: 'fixed', default_horizon: 24 });
    const payload = buildTaskPayload({ model_id: 'm1', solver: 'HiGHS', horizon: 24, parameters: { horizon: 96, demand: 100 } }, config);
    expect(payload).not.toHaveProperty('horizon');
    expect(payload.runtime_parameters).toEqual({ demand: 100 });
    expect(payload.parameters).toEqual(payload.runtime_parameters);
  });

  test('runtime choice horizon is submitted in all backward-compatible locations', () => {
    const config = base({ policy: 'runtime_variable', editable: true, allowed_horizons: [24, 48, 96] });
    const payload = buildTaskPayload({ model_id: 'm1', solver: 'HiGHS', horizon: 96, parameters: { load_forecast: Array(96).fill(1) } }, config);
    expect(payload.horizon).toBe(96);
    expect(payload.runtime_parameters).toMatchObject({ horizon: 96 });
    expect(payload.parameters).toEqual(payload.runtime_parameters);
  });

  test('free horizon validates range and time series length', () => {
    const config = base({ policy: 'runtime_variable', editable: true, min_horizon: 12, max_horizon: 96 });
    expect(validateRuntimeTimeDimension(config, [series], { load_forecast: Array(24).fill(1) }, 24)).toEqual([]);
    expect(validateRuntimeTimeDimension(config, [series], { load_forecast: Array(12).fill(1) }, 24)[0]).toContain('长度应为 24');
  });

  test('data_derived horizon follows the declared field', () => {
    const config = base({ policy: 'data_derived', derive_from: 'load_forecast' });
    expect(deriveHorizon(config, [series], { load_forecast: Array(48).fill(1) })).toBe(48);
  });

  test('state time uses horizon plus one and remains optional when null', () => {
    const state: RuntimeField = { code: 'storage_volume', name: '库容状态', required: true, dimension: ['reservoir', 'time_volume'] };
    const config = base({ policy: 'fixed', default_horizon: 24, state_time_set: 'time_volume' });
    expect(validateRuntimeTimeDimension(config, [state], { storage_volume: [Array(25).fill(1)] })).toEqual([]);
    expect(validateRuntimeTimeDimension(config, [state], { storage_volume: [Array(24).fill(1)] })[0]).toContain('长度应为 25');
    expect(managedTimeFields(base({ state_time_set: null })).has('time_volume')).toBe(false);
  });

  test('managed granularity is filtered only when the contract owns it', () => {
    expect(managedTimeFields(base({ interval_minutes: 15, delta_t: 0.25 })).has('delta_t')).toBe(true);
    expect(managedTimeFields(base({ interval_minutes: undefined, delta_t: undefined })).has('delta_t')).toBe(false);
  });
});
