import { expect, test } from 'vitest';
import { validateTimeSeriesFields } from '../../pages/TaskCenter/TaskCenterPage';

test('keeps the public horizon validation helper backward compatible', () => {
  expect(validateTimeSeriesFields([], {}, { enabled: true, policy: 'runtime_variable', allowed_horizons: [24, 48, 96] }, 36)).toBe('当前模型仅支持 24、48、96 点切换，请选择有效的调度时段。');
});
