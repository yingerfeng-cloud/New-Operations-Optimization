import { Alert, Button, Card, Descriptions, Drawer, Input, InputNumber, Select, Space, Steps, Tag, message } from 'antd';
import { useEffect, useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getModelAssetDetail, getModelSchema } from '../../api/models';
import type { ModelAsset } from '../../types/model';
import { capabilityOrFallback } from '../demo/demoCapabilities';
import { deriveHorizon, managedTimeFields, objectValue, resolveTimeDimension, runtimeFieldsFromContracts, stripSystemTimeParameters, timeDimensionLabel, validateRuntimeTimeDimension } from '../time-dimension';
import { ParameterEditor } from './components/ParameterEditor';
import { buildTaskPayload } from './utils/buildTaskPayload';

const defaultsFrom = (...sources: unknown[]) => Object.assign({}, ...sources.map(source => {
  const record = objectValue(source); const semantic = objectValue(record.semantic_spec); const draft = objectValue(record.model_draft);
  return { ...objectValue(semantic.sample_runtime_parameters), ...objectValue(draft.runtime_parameters), ...objectValue(record.parameters) };
}));

export function TaskCreateWizard({ open, models, submitting, onClose, onSubmit }: { open: boolean; models: ModelAsset[]; submitting?: boolean; onClose: () => void; onSubmit: (payload: Record<string, unknown>) => void }) {
  const [step, setStep] = useState(0);
  const [modelId, setModelId] = useState('');
  const [solver, setSolver] = useState('HiGHS');
  const [horizon, setHorizon] = useState<number>();
  const [parameters, setParameters] = useState<Record<string, unknown>>({});
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [jsonText, setJsonText] = useState('');
  const selected = models.find(model => model.id === modelId);
  const schema = useQuery({ queryKey: ['model-schema', modelId], queryFn: () => getModelSchema(modelId), enabled: open && !!modelId });
  const detail = useQuery({ queryKey: ['model-asset-detail', modelId], queryFn: () => getModelAssetDetail(modelId), enabled: open && !!modelId });
  const fields = useMemo(() => runtimeFieldsFromContracts(schema.data, detail.data), [schema.data, detail.data]);
  const config = useMemo(() => resolveTimeDimension(detail.data, selected, schema.data), [detail.data, selected, schema.data]);
  const visibleFields = useMemo(() => fields.filter(field => !managedTimeFields(config).has(field.code)), [config, fields]);
  const capability = capabilityOrFallback(selected || {});
  const effectiveHorizon = deriveHorizon(config, fields, parameters, horizon);
  const errors = useMemo(() => {
    const required = visibleFields.filter(field => field.required && (parameters[field.code] === undefined || parameters[field.code] === null || parameters[field.code] === '')).map(field => `${field.name} 为必填项`);
    return [...required, ...validateRuntimeTimeDimension(config, fields, parameters, horizon)];
  }, [config, fields, horizon, parameters, visibleFields]);

  useEffect(() => {
    if (!modelId) return;
    const defaults = defaultsFrom(selected, detail.data);
    const next = Object.fromEntries(visibleFields.map(field => [field.code, defaults[field.code] ?? field.defaultValue ?? field.exampleValue]).filter(([, value]) => value !== undefined));
    setParameters(stripSystemTimeParameters(next, config));
    setHorizon(config.default_horizon);
    setSolver(capability.problemType === 'NLP' ? 'Ipopt' : 'HiGHS');
  }, [capability.problemType, config, detail.data, modelId, selected, visibleFields]);

  useEffect(() => { if (!open) { setStep(0); setAdvancedOpen(false); setJsonText(''); } }, [open]);
  const update = (code: string, value: unknown) => setParameters(current => ({ ...current, [code]: value }));
  const importJson = () => {
    try {
      const parsed = JSON.parse(jsonText || '{}'); if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('JSON 必须为对象');
      const sanitized = stripSystemTimeParameters(parsed as Record<string, unknown>, config);
      setParameters(current => ({ ...current, ...sanitized }));
      message.success('参数已导入，系统时间字段已自动忽略');
    } catch (error) { message.error(`导入失败：${String(error)}`); }
  };
  const next = () => { if (step === 0 && !modelId) return message.warning('请先选择模型'); if (step === 1 && errors.length) return message.warning('请先修正参数问题'); setStep(value => Math.min(2, value + 1)); };
  const submit = () => onSubmit(buildTaskPayload({ model_id: modelId, solver, horizon, parameters }, config));

  return <Drawer className="task-create-drawer" title="创建求解任务" open={open} destroyOnHidden size="large" onClose={onClose} footer={<div className="wizard-footer"><Button onClick={onClose}>取消</Button><span className="wizard-footer-spacer" />{step > 0 && <Button onClick={() => setStep(value => value - 1)}>上一步</Button>}{step < 2 ? <Button type="primary" onClick={next}>下一步</Button> : <Button type="primary" loading={submitting} disabled={errors.length > 0} title={errors.length ? '请先修正参数问题' : undefined} onClick={submit}>提交求解并打开详情</Button>}</div>}>
    <Steps current={step} size="small" items={[{ title: '选择模型' }, { title: '填写运行数据' }, { title: '检查并提交' }]} />
    {step === 0 && <div className="wizard-step"><Card title="选择可调用模型" loading={false}><Select aria-label="选择模型" showSearch optionFilterProp="label" value={modelId || undefined} onChange={setModelId} placeholder="按名称选择已发布模型" style={{ width: '100%' }} options={models.filter(model => ['published', 'active', 'online', 'ready'].includes(String(model.status).toLowerCase()) || !model.status).map(model => ({ value: model.id, label: `${model.name} · ${model.version || '当前版本'}` }))} />{selected && <Descriptions className="section-gap" size="small" column={1} bordered items={[{ key: 'scene', label: '适用场景', children: selected.scene || '-' }, { key: 'problem', label: '问题类型', children: capability.problemType || selected.problem_type || '-' }, { key: 'time', label: '时间维度', children: timeDimensionLabel(config, horizon) }, { key: 'solver', label: '默认求解器', children: capability.problemType === 'NLP' ? 'Ipopt' : 'HiGHS' }]} />}</Card></div>}
    {step === 1 && <div className="wizard-step"><Card title="确认调度周期与求解器" loading={schema.isFetching || detail.isFetching}>
      {config.policy === 'not_applicable' && <Alert showIcon type="info" message="该模型不使用调度周期" />}
      {config.policy === 'fixed' && <Alert showIcon type="info" message={`固定调度周期：${config.default_horizon ?? '-'} 点（只读）`} />}
      {config.policy === 'data_derived' && <Alert showIcon type="info" message={`调度周期将由 ${config.derive_from || '主时间序列'} 的长度自动推导`} />}
      {config.policy === 'runtime_variable' && <div className="runtime-control"><label>调度周期</label>{config.allowed_horizons.length ? <Select aria-label="调度周期" value={horizon} onChange={setHorizon} options={config.allowed_horizons.map(value => ({ value, label: `${value} 点${config.interval_minutes_by_horizon[String(value)] ? ` · ${config.interval_minutes_by_horizon[String(value)]} 分钟粒度` : ''}` }))} /> : <InputNumber aria-label="调度周期" value={horizon} min={config.min_horizon || 1} max={config.max_horizon} step={config.horizon_step || 1} onChange={value => setHorizon(value ?? undefined)} />}</div>}
      <div className="runtime-control"><label>求解器</label><Select value={solver} onChange={setSolver} options={capability.problemType === 'NLP' ? [{ value: 'Ipopt', label: 'Ipopt' }] : [{ value: 'HiGHS', label: 'HiGHS' }]} /></div>
    </Card><Card className="section-gap" title="填写业务输入" extra={<Tag>{visibleFields.length} 个字段</Tag>}>
      <div className="parameter-field-list">{visibleFields.map(field => <div className="parameter-field" key={field.code}><div className="parameter-field-label"><strong>{field.name}</strong>{field.required && <Tag color="red">必填</Tag>}<code>{field.code}</code>{field.unit && <span>{field.unit}</span>}</div>{field.description && <p>{field.description}</p>}<ParameterEditor field={field} value={parameters[field.code]} onChange={value => update(field.code, value)} expectedLength={field.dimension.includes(config.state_time_set || '__none__') ? effectiveHorizon ? effectiveHorizon + 1 : undefined : field.dimension.includes(config.time_set) ? effectiveHorizon : undefined} /></div>)}</div>
      {!visibleFields.length && !schema.isFetching && <Alert showIcon type="info" message="当前模型未声明需要手工填写的业务参数" />}
    </Card><Card className="section-gap" title="高级输入（可选）"><Button onClick={() => setAdvancedOpen(value => !value)}>{advancedOpen ? '收起 JSON 导入' : '展开 JSON 导入'}</Button>{advancedOpen && <div className="section-gap-tight"><Input.TextArea rows={5} value={jsonText} onChange={event => setJsonText(event.target.value)} placeholder='{"load_forecast":[100,120]}' /><Button className="section-gap-tight" onClick={importJson}>导入并合并</Button></div>}</Card>{errors.length > 0 && <Alert className="section-gap" showIcon type="warning" message="请修正以下问题" description={<ul>{errors.map(error => <li key={error}>{error}</li>)}</ul>} />}</div>}
    {step === 2 && <div className="wizard-step"><Alert showIcon type={errors.length ? 'warning' : 'success'} message={errors.length ? `发现 ${errors.length} 个待修正问题` : '参数检查通过，可以提交求解'} description={errors.length ? errors.join('；') : '系统时间字段将由模型契约管理，提交结构保持与现有接口兼容。'} /><Descriptions className="section-gap" bordered size="small" column={1} items={[{ key: 'model', label: '模型', children: selected?.name || modelId }, { key: 'time', label: '调度周期', children: timeDimensionLabel(config, effectiveHorizon) }, { key: 'solver', label: '求解器', children: solver }, { key: 'params', label: '业务参数', children: `${Object.keys(parameters).length} 项` }]} /><Card className="section-gap" size="small" title="提交内容预览"><pre className="payload-preview">{JSON.stringify(buildTaskPayload({ model_id: modelId, solver, horizon, parameters }, config), null, 2)}</pre></Card></div>}
  </Drawer>;
}
